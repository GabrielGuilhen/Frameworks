<?php
require_once("../model/conexao.php");
class Bens_moveisDao {
    private $con;
    public function __construct(){
       $this->con=(new Conexao())->conectar();
    }
function inserir($obj) {
    $sql = "INSERT INTO bens_moveis (id, nome_da_escola, itens, marca, estado_do_bem, data_de_aquisicao, id_bem_imovel) VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = $this->con->prepare($sql);
    $id=$obj->getId();
$nome_da_escola=$obj->getNome_da_escola();
$itens=$obj->getItens();
$marca=$obj->getMarca();
$estado_do_bem=$obj->getEstado_do_bem();
$data_de_aquisicao=$obj->getData_de_aquisicao();
$id_bem_imovel=$obj->getId_bem_imovel();

    $stmt->execute([$id,$nome_da_escola,$itens,$marca,$estado_do_bem,$data_de_aquisicao,$id_bem_imovel]);
}
function listaGeral(){
    $sql = "select * from bens_moveis";
    $query = $this->con->query($sql);
    $dados = $query->fetchAll(PDO::FETCH_ASSOC);
    return $dados;
}
 function buscaPorId($id){
    $sql = "select * from bens_moveis where id=$id";
    $query = $this->con->query($sql);
    $dados = $query->fetch(PDO::FETCH_ASSOC);
    return $dados;
}   
function excluir($id){
    $sql = "delete from bens_moveis where id=$id";
    $query = $this->con->query($sql);
    header("Location:../view/listaBens_moveis.php");
}
}
?>