<?php
require_once("../model/conexao.php");
class Bens_imoveisDao {
    private $con;
    public function __construct(){
       $this->con=(new Conexao())->conectar();
    }
function inserir($obj) {
    $sql = "INSERT INTO bens_imoveis (id, nome_da_escola, localizacao, tamanho_em_m2) VALUES (?, ?, ?, ?)";
    $stmt = $this->con->prepare($sql);
    $id=$obj->getId();
$nome_da_escola=$obj->getNome_da_escola();
$localizacao=$obj->getLocalizacao();
$tamanho_em_m2=$obj->getTamanho_em_m2();

    $stmt->execute([$id,$nome_da_escola,$localizacao,$tamanho_em_m2]);
}
function listaGeral(){
    $sql = "select * from bens_imoveis";
    $query = $this->con->query($sql);
    $dados = $query->fetchAll(PDO::FETCH_ASSOC);
    return $dados;
}
 function buscaPorId($id){
    $sql = "select * from bens_imoveis where id=$id";
    $query = $this->con->query($sql);
    $dados = $query->fetch(PDO::FETCH_ASSOC);
    return $dados;
}   
function excluir($id){
    $sql = "delete from bens_imoveis where id=$id";
    $query = $this->con->query($sql);
    header("Location:../view/listaBens_imoveis.php");
}
}
?>