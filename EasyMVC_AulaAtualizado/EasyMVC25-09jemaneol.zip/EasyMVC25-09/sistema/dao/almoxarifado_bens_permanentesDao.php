<?php
require_once("../model/conexao.php");
class Almoxarifado_bens_permanentesDao {
    private $con;
    public function __construct(){
       $this->con=(new Conexao())->conectar();
    }
function inserir($obj) {
    $sql = "INSERT INTO almoxarifado_bens_permanentes (id, id_bem_movel, justificativa, data_transferencia) VALUES (?, ?, ?, ?)";
    $stmt = $this->con->prepare($sql);
    $id=$obj->getId();
$id_bem_movel=$obj->getId_bem_movel();
$justificativa=$obj->getJustificativa();
$data_transferencia=$obj->getData_transferencia();

    $stmt->execute([$id,$id_bem_movel,$justificativa,$data_transferencia]);
}
function listaGeral(){
    $sql = "select * from almoxarifado_bens_permanentes";
    $query = $this->con->query($sql);
    $dados = $query->fetchAll(PDO::FETCH_ASSOC);
    return $dados;
}
 function buscaPorId($id){
    $sql = "select * from almoxarifado_bens_permanentes where id=$id";
    $query = $this->con->query($sql);
    $dados = $query->fetch(PDO::FETCH_ASSOC);
    return $dados;
}   
function excluir($id){
    $sql = "delete from almoxarifado_bens_permanentes where id=$id";
    $query = $this->con->query($sql);
    header("Location:../view/listaAlmoxarifado_bens_permanentes.php");
}
}
?>