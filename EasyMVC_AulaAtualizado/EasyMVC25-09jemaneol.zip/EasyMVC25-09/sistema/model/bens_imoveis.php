<?php
class Bens_imoveis {
	private $id;
	private $nome_da_escola;
	private $localizacao;
	private $tamanho_em_m2;

	function getId(){
		return $this->id;
	}
	function setId($id){
		$this->id=$id;
	}
	function getNome_da_escola(){
		return $this->nome_da_escola;
	}
	function setNome_da_escola($nome_da_escola){
		$this->nome_da_escola=$nome_da_escola;
	}
	function getLocalizacao(){
		return $this->localizacao;
	}
	function setLocalizacao($localizacao){
		$this->localizacao=$localizacao;
	}
	function getTamanho_em_m2(){
		return $this->tamanho_em_m2;
	}
	function setTamanho_em_m2($tamanho_em_m2){
		$this->tamanho_em_m2=$tamanho_em_m2;
	}

}
?>