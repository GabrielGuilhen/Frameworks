<?php
class Bens_moveis {
	private $id;
	private $nome_da_escola;
	private $itens;
	private $marca;
	private $estado_do_bem;
	private $data_de_aquisicao;
	private $id_bem_imovel;

	function getId(){
		return $this->id;
	}
	function setId($id){
		$this->id=$id;
	}
	function getNome_da_escola(){
		return $this->nome_da_escola;
	}
	function setNome_da_escola($nome_da_escola){
		$this->nome_da_escola=$nome_da_escola;
	}
	function getItens(){
		return $this->itens;
	}
	function setItens($itens){
		$this->itens=$itens;
	}
	function getMarca(){
		return $this->marca;
	}
	function setMarca($marca){
		$this->marca=$marca;
	}
	function getEstado_do_bem(){
		return $this->estado_do_bem;
	}
	function setEstado_do_bem($estado_do_bem){
		$this->estado_do_bem=$estado_do_bem;
	}
	function getData_de_aquisicao(){
		return $this->data_de_aquisicao;
	}
	function setData_de_aquisicao($data_de_aquisicao){
		$this->data_de_aquisicao=$data_de_aquisicao;
	}
	function getId_bem_imovel(){
		return $this->id_bem_imovel;
	}
	function setId_bem_imovel($id_bem_imovel){
		$this->id_bem_imovel=$id_bem_imovel;
	}

}
?>