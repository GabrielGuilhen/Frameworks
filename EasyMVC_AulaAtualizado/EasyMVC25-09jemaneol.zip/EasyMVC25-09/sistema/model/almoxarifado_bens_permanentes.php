<?php
class Almoxarifado_bens_permanentes {
	private $id;
	private $id_bem_movel;
	private $justificativa;
	private $data_transferencia;

	function getId(){
		return $this->id;
	}
	function setId($id){
		$this->id=$id;
	}
	function getId_bem_movel(){
		return $this->id_bem_movel;
	}
	function setId_bem_movel($id_bem_movel){
		$this->id_bem_movel=$id_bem_movel;
	}
	function getJustificativa(){
		return $this->justificativa;
	}
	function setJustificativa($justificativa){
		$this->justificativa=$justificativa;
	}
	function getData_transferencia(){
		return $this->data_transferencia;
	}
	function setData_transferencia($data_transferencia){
		$this->data_transferencia=$data_transferencia;
	}

}
?>