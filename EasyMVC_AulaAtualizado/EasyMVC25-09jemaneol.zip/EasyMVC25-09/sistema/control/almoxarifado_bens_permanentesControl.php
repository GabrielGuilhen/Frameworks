<?php
require_once("../model/almoxarifado_bens_permanentes.php");
require_once("../dao/almoxarifado_bens_permanentesDao.php");
class Almoxarifado_bens_permanentesControl {
    private $almoxarifado_bens_permanentes;
    private $acao;
    private $dao;
    public function __construct(){
       $this->almoxarifado_bens_permanentes=new Almoxarifado_bens_permanentes();
      $this->dao=new Almoxarifado_bens_permanentesDao();
      $this->acao=$_GET["a"];
      $this->verificaAcao(); 
    }
    function verificaAcao(){
       switch($this->acao){
          case 1:
            $this->inserir();
          break;
          case 2:
            $this->excluir();
          break;
       }
    }
  
    function inserir(){
        $this->almoxarifado_bens_permanentes->setId($_POST['id']);
		$this->almoxarifado_bens_permanentes->setId_bem_movel($_POST['id_bem_movel']);
		$this->almoxarifado_bens_permanentes->setJustificativa($_POST['justificativa']);
		$this->almoxarifado_bens_permanentes->setData_transferencia($_POST['data_transferencia']);
		
        $this->dao->inserir($this->almoxarifado_bens_permanentes);
    }
    function excluir(){
        $this->dao->excluir($_REQUEST['id']);
    }
    function alterar(){}
    function buscarId(Almoxarifado_bens_permanentes $almoxarifado_bens_permanentes){}
    function buscaTodos(){}

}
new Almoxarifado_bens_permanentesControl();
?>