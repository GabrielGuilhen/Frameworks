<?php
require_once("../model/bens_moveis.php");
require_once("../dao/bens_moveisDao.php");
class Bens_moveisControl {
    private $bens_moveis;
    private $acao;
    private $dao;
    public function __construct(){
       $this->bens_moveis=new Bens_moveis();
      $this->dao=new Bens_moveisDao();
      $this->acao=$_GET["a"];
      $this->verificaAcao(); 
    }
    function verificaAcao(){
       switch($this->acao){
          case 1:
            $this->inserir();
          break;
          case 2:
            $this->excluir();
          break;
       }
    }
  
    function inserir(){
        $this->bens_moveis->setId($_POST['id']);
		$this->bens_moveis->setNome_da_escola($_POST['nome_da_escola']);
		$this->bens_moveis->setItens($_POST['itens']);
		$this->bens_moveis->setMarca($_POST['marca']);
		$this->bens_moveis->setEstado_do_bem($_POST['estado_do_bem']);
		$this->bens_moveis->setData_de_aquisicao($_POST['data_de_aquisicao']);
		$this->bens_moveis->setId_bem_imovel($_POST['id_bem_imovel']);
		
        $this->dao->inserir($this->bens_moveis);
    }
    function excluir(){
        $this->dao->excluir($_REQUEST['id']);
    }
    function alterar(){}
    function buscarId(Bens_moveis $bens_moveis){}
    function buscaTodos(){}

}
new Bens_moveisControl();
?>