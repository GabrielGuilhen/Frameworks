<?php
require_once("../model/bens_imoveis.php");
require_once("../dao/bens_imoveisDao.php");
class Bens_imoveisControl {
    private $bens_imoveis;
    private $acao;
    private $dao;
    public function __construct(){
       $this->bens_imoveis=new Bens_imoveis();
      $this->dao=new Bens_imoveisDao();
      $this->acao=$_GET["a"];
      $this->verificaAcao(); 
    }
    function verificaAcao(){
       switch($this->acao){
          case 1:
            $this->inserir();
          break;
          case 2:
            $this->excluir();
          break;
       }
    }
  
    function inserir(){
        $this->bens_imoveis->setId($_POST['id']);
		$this->bens_imoveis->setNome_da_escola($_POST['nome_da_escola']);
		$this->bens_imoveis->setLocalizacao($_POST['localizacao']);
		$this->bens_imoveis->setTamanho_em_m2($_POST['tamanho_em_m2']);
		
        $this->dao->inserir($this->bens_imoveis);
    }
    function excluir(){
        $this->dao->excluir($_REQUEST['id']);
    }
    function alterar(){}
    function buscarId(Bens_imoveis $bens_imoveis){}
    function buscaTodos(){}

}
new Bens_imoveisControl();
?>