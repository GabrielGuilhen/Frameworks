
<html>
    <head>
        <title>Lista de almoxarifado_bens_permanentes</title>
        <link rel="stylesheet" href="../css/estilos.css">
    </head>
    <body>
      <?php
      require_once("../dao/almoxarifado_bens_permanentesDao.php");
   $dao=new almoxarifado_bens_permanentesDAO();
   $dados=$dao->listaGeral();
    echo "<table border=1>";
    foreach($dados as $dado){
        echo "<tr>";
       echo "<td>{$dado['id']}</td>";
echo "<td>{$dado['id_bem_movel']}</td>";
echo "<td>{$dado['justificativa']}</td>";
echo "<td>{$dado['data_transferencia']}</td>";

       echo "<td>".
       "<a href='../control/almoxarifado_bens_permanentesControl.php?id={$dado['id']}&a=2'> Excluir</a>".
       "</td>";
       echo "<td>" . 
        "<a href='../view/almoxarifado_bens_permanentes.php?id={$dado['id']}'> Alterar</a>" .
       "</td>";
       echo "</tr>";
    }
    echo "</table>";
     ?>  
    </body>
</html>