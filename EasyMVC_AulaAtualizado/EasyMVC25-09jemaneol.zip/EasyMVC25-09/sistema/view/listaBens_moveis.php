
<html>
    <head>
        <title>Lista de bens_moveis</title>
        <link rel="stylesheet" href="../css/estilos.css">
    </head>
    <body>
      <?php
      require_once("../dao/bens_moveisDao.php");
   $dao=new bens_moveisDAO();
   $dados=$dao->listaGeral();
    echo "<table border=1>";
    foreach($dados as $dado){
        echo "<tr>";
       echo "<td>{$dado['id']}</td>";
echo "<td>{$dado['nome_da_escola']}</td>";
echo "<td>{$dado['itens']}</td>";
echo "<td>{$dado['marca']}</td>";
echo "<td>{$dado['estado_do_bem']}</td>";
echo "<td>{$dado['data_de_aquisicao']}</td>";
echo "<td>{$dado['id_bem_imovel']}</td>";

       echo "<td>".
       "<a href='../control/bens_moveisControl.php?id={$dado['id']}&a=2'> Excluir</a>".
       "</td>";
       echo "<td>" . 
        "<a href='../view/bens_moveis.php?id={$dado['id']}'> Alterar</a>" .
       "</td>";
       echo "</tr>";
    }
    echo "</table>";
     ?>  
    </body>
</html>