<?php
    require_once('../dao/almoxarifado_bens_permanentesDao.php');
    $obj=null;
    if(isset($_GET['id']))
    $obj=(new almoxarifado_bens_permanentesDao())->buscaPorId($_GET['id']);
    $acao=$obj?3:1;
?>
<html>
    <head>
        <title>Cadastro de almoxarifado_bens_permanentes</title>
        <link rel="stylesheet" href="../css/estilos.css">
    </head>
    <body>
        <form action="../control/almoxarifado_bens_permanentesControl.php?a=<?php echo $acao ?>" method="post">
        <h1>Cadastro de almoxarifado_bens_permanentes</h1>
            <label for='id'>id</label>
<input type='text' value='<?php echo $obj?$obj['id']:''; ?>'name='id'><br>
<label for='id_bem_movel'>id_bem_movel</label>
<input type='text' value='<?php echo $obj?$obj['id_bem_movel']:''; ?>'name='id_bem_movel'><br>
<label for='justificativa'>justificativa</label>
<input type='text' value='<?php echo $obj?$obj['justificativa']:''; ?>'name='justificativa'><br>
<label for='data_transferencia'>data_transferencia</label>
<input type='text' value='<?php echo $obj?$obj['data_transferencia']:''; ?>'name='data_transferencia'><br>

             <button type="submit">Enviar</button>
        </form>
    </body>
</html>