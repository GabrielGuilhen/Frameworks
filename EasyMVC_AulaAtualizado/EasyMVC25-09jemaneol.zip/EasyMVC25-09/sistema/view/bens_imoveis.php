<?php
    require_once('../dao/bens_imoveisDao.php');
    $obj=null;
    if(isset($_GET['id']))
    $obj=(new bens_imoveisDao())->buscaPorId($_GET['id']);
    $acao=$obj?3:1;
?>
<html>
    <head>
        <title>Cadastro de bens_imoveis</title>
        <link rel="stylesheet" href="../css/estilos.css">
    </head>
    <body>
        <form action="../control/bens_imoveisControl.php?a=<?php echo $acao ?>" method="post">
        <h1>Cadastro de bens_imoveis</h1>
            <label for='id'>id</label>
<input type='text' value='<?php echo $obj?$obj['id']:''; ?>'name='id'><br>
<label for='nome_da_escola'>nome_da_escola</label>
<input type='text' value='<?php echo $obj?$obj['nome_da_escola']:''; ?>'name='nome_da_escola'><br>
<label for='localizacao'>localizacao</label>
<input type='text' value='<?php echo $obj?$obj['localizacao']:''; ?>'name='localizacao'><br>
<label for='tamanho_em_m2'>tamanho_em_m2</label>
<input type='text' value='<?php echo $obj?$obj['tamanho_em_m2']:''; ?>'name='tamanho_em_m2'><br>

             <button type="submit">Enviar</button>
        </form>
    </body>
</html>