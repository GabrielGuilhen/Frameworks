<?php
    require_once('../dao/bens_moveisDao.php');
    $obj=null;
    if(isset($_GET['id']))
    $obj=(new bens_moveisDao())->buscaPorId($_GET['id']);
    $acao=$obj?3:1;
?>
<html>
    <head>
        <title>Cadastro de bens_moveis</title>
        <link rel="stylesheet" href="../css/estilos.css">
    </head>
    <body>
        <form action="../control/bens_moveisControl.php?a=<?php echo $acao ?>" method="post">
        <h1>Cadastro de bens_moveis</h1>
            <label for='id'>id</label>
<input type='text' value='<?php echo $obj?$obj['id']:''; ?>'name='id'><br>
<label for='nome_da_escola'>nome_da_escola</label>
<input type='text' value='<?php echo $obj?$obj['nome_da_escola']:''; ?>'name='nome_da_escola'><br>
<label for='itens'>itens</label>
<input type='text' value='<?php echo $obj?$obj['itens']:''; ?>'name='itens'><br>
<label for='marca'>marca</label>
<input type='text' value='<?php echo $obj?$obj['marca']:''; ?>'name='marca'><br>
<label for='estado_do_bem'>estado_do_bem</label>
<input type='text' value='<?php echo $obj?$obj['estado_do_bem']:''; ?>'name='estado_do_bem'><br>
<label for='data_de_aquisicao'>data_de_aquisicao</label>
<input type='text' value='<?php echo $obj?$obj['data_de_aquisicao']:''; ?>'name='data_de_aquisicao'><br>
<label for='id_bem_imovel'>id_bem_imovel</label>
<input type='text' value='<?php echo $obj?$obj['id_bem_imovel']:''; ?>'name='id_bem_imovel'><br>

             <button type="submit">Enviar</button>
        </form>
    </body>
</html>