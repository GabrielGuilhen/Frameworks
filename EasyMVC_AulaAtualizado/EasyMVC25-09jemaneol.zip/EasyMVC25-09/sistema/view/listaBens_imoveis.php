
<html>
    <head>
        <title>Lista de bens_imoveis</title>
        <link rel="stylesheet" href="../css/estilos.css">
    </head>
    <body>
      <?php
      require_once("../dao/bens_imoveisDao.php");
   $dao=new bens_imoveisDAO();
   $dados=$dao->listaGeral();
    echo "<table border=1>";
    foreach($dados as $dado){
        echo "<tr>";
       echo "<td>{$dado['id']}</td>";
echo "<td>{$dado['nome_da_escola']}</td>";
echo "<td>{$dado['localizacao']}</td>";
echo "<td>{$dado['tamanho_em_m2']}</td>";

       echo "<td>".
       "<a href='../control/bens_imoveisControl.php?id={$dado['id']}&a=2'> Excluir</a>".
       "</td>";
       echo "<td>" . 
        "<a href='../view/bens_imoveis.php?id={$dado['id']}'> Alterar</a>" .
       "</td>";
       echo "</tr>";
    }
    echo "</table>";
     ?>  
    </body>
</html>