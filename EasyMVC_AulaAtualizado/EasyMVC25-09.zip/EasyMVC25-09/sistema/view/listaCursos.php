
<html>
    <head>
        <title>Lista de Cursos</title>
        <link rel="stylesheet" href="../css/estilos.css">
    </head>
    <body>
      <?php
      require_once("../dao/CursosDao.php");
   $dao=new cursosDAO();
   $dados=$dao->listaGeral();
    foreach($dados as $dado){
       echo $dado['id'];echo $dado['nome'];echo $dado['turno'];;
    }
     ?>  
    </body>
</html>