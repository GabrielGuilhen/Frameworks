
<html>
    <head>
        <title>Lista de Alunos</title>
        <link rel="stylesheet" href="../css/estilos.css">
    </head>
    <body>
      <?php
      require_once("../dao/AlunosDao.php");
   $dao=new alunosDAO();
   $dados=$dao->listaGeral();
    foreach($dados as $dado){
       echo $dado['id'];echo $dado['nome'];echo $dado['idade'];echo $dado['estrangeiro'];echo $dado['id_curso'];;
    }
     ?>  
    </body>
</html>