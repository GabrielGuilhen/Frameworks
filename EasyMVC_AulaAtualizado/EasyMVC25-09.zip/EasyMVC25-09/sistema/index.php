<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Db_alunos</title>
    <style>
    body {
        margin: 0;
        font-family: Arial, sans-serif;
    }
    .cabecalho {
        width: 100%;
        height: 200px;
        background-color: #2c3e50;
        color: white;
        display: flex;
        justify-content: center;
        align-items: center;
        font-size: 24px;
        font-weight: bold;
    }
    .menu {
        width: 100%;
        height: 100px;
        background-color: #34495e;
        display: flex;
        align-items: center;
        padding-left: 20px;
    }
    .menu ul {
        list-style: none;
        margin: 0;
        padding: 0;
        display: flex;
        gap: 40px;
    }
    .menu li {
        position: relative;
    }
    .menu a {
        color: white;
        text-decoration: none;
        font-size: 18px;
        padding: 10px;
        display: block;
    }
    .menu li ul {
        display: none;
        position: absolute;
        top: 100%;
        left: 0;
        background-color: #2c3e50;
        list-style: none;
        padding: 0;
        margin: 0;
        min-width: 200px;
    }
    .menu li ul li a {
        padding: 10px;
        font-size: 16px;
    }
    .menu li:hover ul {
        display: block;
    }
    .conteudo {
        min-height: calc(100vh - 300px);
        padding: 20px;
        background-color: #ecf0f1;
    }
    </style>
</head>
<body>
    <div class="cabecalho">
        Sistema Db_alunos
    </div>
    <div class="menu">
        <ul>
            <li>
                <a href="#">Cadastros</a>
                <ul>
                    <li><a href="/view/alunos.php">Cadastro de Alunos</a></li>
                <li><a href="/view/cursos.php">Cadastro de Cursos</a></li>
                
                </ul>
            </li>
            <li>
                <a href="#">Relatórios</a>
                <ul>
                    <li><a href="/view/listaAlunos.php">Relatório de Alunos</a></li>
                <li><a href="/view/listaCursos.php">Relatório de Cursos</a></li>
                
                </ul>
            </li>
        </ul>
    </div>
    <div class="conteudo">
        <h2>Bem-vindo ao Sistema Db_alunos!</h2>
        <p>Utilize o menu acima para navegar pelas funcionalidades do sistema.</p>
        <p>Você pode acessar os cadastros e relatórios através dos menus correspondentes.</p>
    </div>
</body>
</html>