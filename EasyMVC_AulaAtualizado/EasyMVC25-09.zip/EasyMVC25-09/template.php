<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Cadastro de <?php echo $nomeTabela; ?></title>
    <link rel="stylesheet" href="../css/estilos.css">
    <style>
        
    </style>
</head>
<body>
<div class="cabecalho">
    <?php echo $nomeSistema; ?>
</div>
<div class="menu">
</div>
<div class="conteudo">
    <h2>Cadastro de <?php echo $nomeTabela; ?></h2>
    <form action="../control/<?php echo $nomeTabela; ?>Control.php?a=<?php echo $acao; ?>" method="post">
        <?php echo $camposFormulario; ?>
        <button type="submit">Enviar</button>
    </form>
</div>
</body>
</html>