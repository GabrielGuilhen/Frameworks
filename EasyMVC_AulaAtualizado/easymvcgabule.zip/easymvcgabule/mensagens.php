<?php
$mensagens = ['Erro 0: No foi possível criar diretórios ',
    'Erro 1: Falha ao conectar ao banco de dados',
    'Projeto criado: faça download clicando <a href=sistema.zip>aqui</a>',
    'Erro 2: Não foi possível obter as tabelas'];