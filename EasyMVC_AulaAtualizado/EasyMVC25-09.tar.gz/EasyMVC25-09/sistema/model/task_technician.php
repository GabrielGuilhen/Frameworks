<?php
class Task_technician {
	private $id;
	private $id_task;
	private $id_technician;
	private $status;
	private $is_owner;
	private $invited_by;
	private $invited_at;

	function getId(){
		return $this->id;
	}
	function setId($id){
		$this->id=$id;
	}
	function getId_task(){
		return $this->id_task;
	}
	function setId_task($id_task){
		$this->id_task=$id_task;
	}
	function getId_technician(){
		return $this->id_technician;
	}
	function setId_technician($id_technician){
		$this->id_technician=$id_technician;
	}
	function getStatus(){
		return $this->status;
	}
	function setStatus($status){
		$this->status=$status;
	}
	function getIs_owner(){
		return $this->is_owner;
	}
	function setIs_owner($is_owner){
		$this->is_owner=$is_owner;
	}
	function getInvited_by(){
		return $this->invited_by;
	}
	function setInvited_by($invited_by){
		$this->invited_by=$invited_by;
	}
	function getInvited_at(){
		return $this->invited_at;
	}
	function setInvited_at($invited_at){
		$this->invited_at=$invited_at;
	}

}
?>