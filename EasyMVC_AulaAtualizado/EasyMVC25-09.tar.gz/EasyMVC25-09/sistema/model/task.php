<?php
class Task {
	private $id;
	private $title;
	private $description;
	private $scheduled_date;
	private $scheduled_time;
	private $location;
	private $task_status;
	private $id_client;

	function getId(){
		return $this->id;
	}
	function setId($id){
		$this->id=$id;
	}
	function getTitle(){
		return $this->title;
	}
	function setTitle($title){
		$this->title=$title;
	}
	function getDescription(){
		return $this->description;
	}
	function setDescription($description){
		$this->description=$description;
	}
	function getScheduled_date(){
		return $this->scheduled_date;
	}
	function setScheduled_date($scheduled_date){
		$this->scheduled_date=$scheduled_date;
	}
	function getScheduled_time(){
		return $this->scheduled_time;
	}
	function setScheduled_time($scheduled_time){
		$this->scheduled_time=$scheduled_time;
	}
	function getLocation(){
		return $this->location;
	}
	function setLocation($location){
		$this->location=$location;
	}
	function getTask_status(){
		return $this->task_status;
	}
	function setTask_status($task_status){
		$this->task_status=$task_status;
	}
	function getId_client(){
		return $this->id_client;
	}
	function setId_client($id_client){
		$this->id_client=$id_client;
	}

}
?>