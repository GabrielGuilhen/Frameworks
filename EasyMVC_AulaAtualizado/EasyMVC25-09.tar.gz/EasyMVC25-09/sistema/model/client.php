<?php
class Client {
	private $id;
	private $name;
	private $phone;
	private $id_technician;

	function getId(){
		return $this->id;
	}
	function setId($id){
		$this->id=$id;
	}
	function getName(){
		return $this->name;
	}
	function setName($name){
		$this->name=$name;
	}
	function getPhone(){
		return $this->phone;
	}
	function setPhone($phone){
		$this->phone=$phone;
	}
	function getId_technician(){
		return $this->id_technician;
	}
	function setId_technician($id_technician){
		$this->id_technician=$id_technician;
	}

}
?>