<?php
class Budget {
	private $id;
	private $title;
	private $description;
	private $validity;
	private $value;
	private $status;
	private $id_technician;
	private $id_client;

	function getId(){
		return $this->id;
	}
	function setId($id){
		$this->id=$id;
	}
	function getTitle(){
		return $this->title;
	}
	function setTitle($title){
		$this->title=$title;
	}
	function getDescription(){
		return $this->description;
	}
	function setDescription($description){
		$this->description=$description;
	}
	function getValidity(){
		return $this->validity;
	}
	function setValidity($validity){
		$this->validity=$validity;
	}
	function getValue(){
		return $this->value;
	}
	function setValue($value){
		$this->value=$value;
	}
	function getStatus(){
		return $this->status;
	}
	function setStatus($status){
		$this->status=$status;
	}
	function getId_technician(){
		return $this->id_technician;
	}
	function setId_technician($id_technician){
		$this->id_technician=$id_technician;
	}
	function getId_client(){
		return $this->id_client;
	}
	function setId_client($id_client){
		$this->id_client=$id_client;
	}

}
?>