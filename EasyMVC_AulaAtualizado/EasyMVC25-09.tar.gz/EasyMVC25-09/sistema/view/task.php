<?php
    require_once('../dao/taskDao.php');
    $obj=null;
    if(isset($_GET['id']))
    $obj=(new taskDao())->buscaPorId($_GET['id']);
    $acao=$obj?3:1;
?>
<html>
    <head>
        <title>Cadastro de task</title>
        <link rel="stylesheet" href="../css/estilos.css">
    </head>
    <body>
        <form action="../control/taskControl.php?a=<?php echo $acao ?>" method="post">
        <h1>Cadastro de task</h1>
            <label for='id'>id</label>
<input type='text' value='<?php echo $obj?$obj['id']:''; ?>'name='id'><br>
<label for='title'>title</label>
<input type='text' value='<?php echo $obj?$obj['title']:''; ?>'name='title'><br>
<label for='description'>description</label>
<input type='text' value='<?php echo $obj?$obj['description']:''; ?>'name='description'><br>
<label for='scheduled_date'>scheduled_date</label>
<input type='text' value='<?php echo $obj?$obj['scheduled_date']:''; ?>'name='scheduled_date'><br>
<label for='scheduled_time'>scheduled_time</label>
<input type='text' value='<?php echo $obj?$obj['scheduled_time']:''; ?>'name='scheduled_time'><br>
<label for='location'>location</label>
<input type='text' value='<?php echo $obj?$obj['location']:''; ?>'name='location'><br>
<label for='task_status'>task_status</label>
<input type='text' value='<?php echo $obj?$obj['task_status']:''; ?>'name='task_status'><br>
<label for='id_client'>id_client</label>
<input type='text' value='<?php echo $obj?$obj['id_client']:''; ?>'name='id_client'><br>

             <button type="submit">Enviar</button>
        </form>
    </body>
</html>