
<html>
    <head>
        <title>Lista de pmoc</title>
        <link rel="stylesheet" href="../css/estilos.css">
    </head>
    <body>
      <?php
      require_once("../dao/pmocDao.php");
   $dao=new pmocDAO();
   $dados=$dao->listaGeral();
    echo "<table border=1>";
    foreach($dados as $dado){
        echo "<tr>";
       echo "<td>{$dado['id']}</td>";
echo "<td>{$dado['name']}</td>";
echo "<td>{$dado['creation_date']}</td>";
echo "<td>{$dado['service_address']}</td>";
echo "<td>{$dado['description']}</td>";
echo "<td>{$dado['id_technician']}</td>";
echo "<td>{$dado['id_client']}</td>";

       echo "<td>".
       "<a href='../control/pmocControl.php?id={$dado['id']}&a=2'> Excluir</a>".
       "</td>";
       echo "<td>" . 
        "<a href='../view/pmoc.php?id={$dado['id']}'> Alterar</a>" .
       "</td>";
       echo "</tr>";
    }
    echo "</table>";
     ?>  
    </body>
</html>