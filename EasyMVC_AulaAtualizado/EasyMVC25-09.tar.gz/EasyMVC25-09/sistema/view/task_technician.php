<?php
    require_once('../dao/task_technicianDao.php');
    $obj=null;
    if(isset($_GET['id']))
    $obj=(new task_technicianDao())->buscaPorId($_GET['id']);
    $acao=$obj?3:1;
?>
<html>
    <head>
        <title>Cadastro de task_technician</title>
        <link rel="stylesheet" href="../css/estilos.css">
    </head>
    <body>
        <form action="../control/task_technicianControl.php?a=<?php echo $acao ?>" method="post">
        <h1>Cadastro de task_technician</h1>
            <label for='id'>id</label>
<input type='text' value='<?php echo $obj?$obj['id']:''; ?>'name='id'><br>
<label for='id_task'>id_task</label>
<input type='text' value='<?php echo $obj?$obj['id_task']:''; ?>'name='id_task'><br>
<label for='id_technician'>id_technician</label>
<input type='text' value='<?php echo $obj?$obj['id_technician']:''; ?>'name='id_technician'><br>
<label for='status'>status</label>
<input type='text' value='<?php echo $obj?$obj['status']:''; ?>'name='status'><br>
<label for='is_owner'>is_owner</label>
<input type='text' value='<?php echo $obj?$obj['is_owner']:''; ?>'name='is_owner'><br>
<label for='invited_by'>invited_by</label>
<input type='text' value='<?php echo $obj?$obj['invited_by']:''; ?>'name='invited_by'><br>
<label for='invited_at'>invited_at</label>
<input type='text' value='<?php echo $obj?$obj['invited_at']:''; ?>'name='invited_at'><br>

             <button type="submit">Enviar</button>
        </form>
    </body>
</html>