<?php
    require_once('../dao/clientDao.php');
    $obj=null;
    if(isset($_GET['id']))
    $obj=(new clientDao())->buscaPorId($_GET['id']);
    $acao=$obj?3:1;
?>
<html>
    <head>
        <title>Cadastro de client</title>
        <link rel="stylesheet" href="../css/estilos.css">
    </head>
    <body>
        <form action="../control/clientControl.php?a=<?php echo $acao ?>" method="post">
        <h1>Cadastro de client</h1>
            <label for='id'>id</label>
<input type='text' value='<?php echo $obj?$obj['id']:''; ?>'name='id'><br>
<label for='name'>name</label>
<input type='text' value='<?php echo $obj?$obj['name']:''; ?>'name='name'><br>
<label for='phone'>phone</label>
<input type='text' value='<?php echo $obj?$obj['phone']:''; ?>'name='phone'><br>
<label for='id_technician'>id_technician</label>
<input type='text' value='<?php echo $obj?$obj['id_technician']:''; ?>'name='id_technician'><br>

             <button type="submit">Enviar</button>
        </form>
    </body>
</html>