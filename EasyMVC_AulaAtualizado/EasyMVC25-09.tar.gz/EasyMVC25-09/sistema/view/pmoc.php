<?php
    require_once('../dao/pmocDao.php');
    $obj=null;
    if(isset($_GET['id']))
    $obj=(new pmocDao())->buscaPorId($_GET['id']);
    $acao=$obj?3:1;
?>
<html>
    <head>
        <title>Cadastro de pmoc</title>
        <link rel="stylesheet" href="../css/estilos.css">
    </head>
    <body>
        <form action="../control/pmocControl.php?a=<?php echo $acao ?>" method="post">
        <h1>Cadastro de pmoc</h1>
            <label for='id'>id</label>
<input type='text' value='<?php echo $obj?$obj['id']:''; ?>'name='id'><br>
<label for='name'>name</label>
<input type='text' value='<?php echo $obj?$obj['name']:''; ?>'name='name'><br>
<label for='creation_date'>creation_date</label>
<input type='text' value='<?php echo $obj?$obj['creation_date']:''; ?>'name='creation_date'><br>
<label for='service_address'>service_address</label>
<input type='text' value='<?php echo $obj?$obj['service_address']:''; ?>'name='service_address'><br>
<label for='description'>description</label>
<input type='text' value='<?php echo $obj?$obj['description']:''; ?>'name='description'><br>
<label for='id_technician'>id_technician</label>
<input type='text' value='<?php echo $obj?$obj['id_technician']:''; ?>'name='id_technician'><br>
<label for='id_client'>id_client</label>
<input type='text' value='<?php echo $obj?$obj['id_client']:''; ?>'name='id_client'><br>

             <button type="submit">Enviar</button>
        </form>
    </body>
</html>