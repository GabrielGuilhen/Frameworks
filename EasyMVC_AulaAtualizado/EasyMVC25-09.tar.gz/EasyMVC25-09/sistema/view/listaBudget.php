
<html>
    <head>
        <title>Lista de budget</title>
        <link rel="stylesheet" href="../css/estilos.css">
    </head>
    <body>
      <?php
      require_once("../dao/budgetDao.php");
   $dao=new budgetDAO();
   $dados=$dao->listaGeral();
    echo "<table border=1>";
    foreach($dados as $dado){
        echo "<tr>";
       echo "<td>{$dado['id']}</td>";
echo "<td>{$dado['title']}</td>";
echo "<td>{$dado['description']}</td>";
echo "<td>{$dado['validity']}</td>";
echo "<td>{$dado['value']}</td>";
echo "<td>{$dado['status']}</td>";
echo "<td>{$dado['id_technician']}</td>";
echo "<td>{$dado['id_client']}</td>";

       echo "<td>".
       "<a href='../control/budgetControl.php?id={$dado['id']}&a=2'> Excluir</a>".
       "</td>";
       echo "<td>" . 
        "<a href='../view/budget.php?id={$dado['id']}'> Alterar</a>" .
       "</td>";
       echo "</tr>";
    }
    echo "</table>";
     ?>  
    </body>
</html>