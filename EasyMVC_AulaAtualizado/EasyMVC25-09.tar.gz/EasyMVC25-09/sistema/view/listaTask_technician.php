
<html>
    <head>
        <title>Lista de task_technician</title>
        <link rel="stylesheet" href="../css/estilos.css">
    </head>
    <body>
      <?php
      require_once("../dao/task_technicianDao.php");
   $dao=new task_technicianDAO();
   $dados=$dao->listaGeral();
    echo "<table border=1>";
    foreach($dados as $dado){
        echo "<tr>";
       echo "<td>{$dado['id']}</td>";
echo "<td>{$dado['id_task']}</td>";
echo "<td>{$dado['id_technician']}</td>";
echo "<td>{$dado['status']}</td>";
echo "<td>{$dado['is_owner']}</td>";
echo "<td>{$dado['invited_by']}</td>";
echo "<td>{$dado['invited_at']}</td>";

       echo "<td>".
       "<a href='../control/task_technicianControl.php?id={$dado['id']}&a=2'> Excluir</a>".
       "</td>";
       echo "<td>" . 
        "<a href='../view/task_technician.php?id={$dado['id']}'> Alterar</a>" .
       "</td>";
       echo "</tr>";
    }
    echo "</table>";
     ?>  
    </body>
</html>