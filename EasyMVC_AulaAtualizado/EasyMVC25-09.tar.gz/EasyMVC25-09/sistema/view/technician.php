<?php
    require_once('../dao/technicianDao.php');
    $obj=null;
    if(isset($_GET['id']))
    $obj=(new technicianDao())->buscaPorId($_GET['id']);
    $acao=$obj?3:1;
?>
