<?php
    require_once('../dao/budgetDao.php');
    $obj=null;
    if(isset($_GET['id']))
    $obj=(new budgetDao())->buscaPorId($_GET['id']);
    $acao=$obj?3:1;
?>
<html>
    <head>
        <title>Cadastro de budget</title>
        <link rel="stylesheet" href="../css/estilos.css">
    </head>
    <body>
        <form action="../control/budgetControl.php?a=<?php echo $acao ?>" method="post">
        <h1>Cadastro de budget</h1>
            <label for='id'>id</label>
<input type='text' value='<?php echo $obj?$obj['id']:''; ?>'name='id'><br>
<label for='title'>title</label>
<input type='text' value='<?php echo $obj?$obj['title']:''; ?>'name='title'><br>
<label for='description'>description</label>
<input type='text' value='<?php echo $obj?$obj['description']:''; ?>'name='description'><br>
<label for='validity'>validity</label>
<input type='text' value='<?php echo $obj?$obj['validity']:''; ?>'name='validity'><br>
<label for='value'>value</label>
<input type='text' value='<?php echo $obj?$obj['value']:''; ?>'name='value'><br>
<label for='status'>status</label>
<input type='text' value='<?php echo $obj?$obj['status']:''; ?>'name='status'><br>
<label for='id_technician'>id_technician</label>
<input type='text' value='<?php echo $obj?$obj['id_technician']:''; ?>'name='id_technician'><br>
<label for='id_client'>id_client</label>
<input type='text' value='<?php echo $obj?$obj['id_client']:''; ?>'name='id_client'><br>

             <button type="submit">Enviar</button>
        </form>
    </body>
</html>