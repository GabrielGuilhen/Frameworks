
<html>
    <head>
        <title>Lista de technician</title>
        <link rel="stylesheet" href="../css/estilos.css">
    </head>
    <body>
      <?php
      require_once("../dao/technicianDao.php");
   $dao=new technicianDAO();
   $dados=$dao->listaGeral();
    echo "<table border=1>";
    foreach($dados as $dado){
        echo "<tr>";
       echo "<td>{$dado['id']}</td>";
echo "<td>{$dado['cpf_cnpj']}</td>";
echo "<td>{$dado['name']}</td>";
echo "<td>{$dado['address']}</td>";
echo "<td>{$dado['phone']}</td>";
echo "<td>{$dado['crea']}</td>";
echo "<td>{$dado['email']}</td>";
echo "<td>{$dado['password']}</td>";

       echo "<td>".
       "<a href='../control/technicianControl.php?id={$dado['id']}&a=2'> Excluir</a>".
       "</td>";
       echo "<td>" . 
        "<a href='../view/technician.php?id={$dado['id']}'> Alterar</a>" .
       "</td>";
       echo "</tr>";
    }
    echo "</table>";
     ?>  
    </body>
</html>