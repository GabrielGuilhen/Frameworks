<?php
    require_once('../dao/air_conditionerDao.php');
    $obj=null;
    if(isset($_GET['id']))
    $obj=(new air_conditionerDao())->buscaPorId($_GET['id']);
    $acao=$obj?3:1;
?>
<html>
    <head>
        <title>Cadastro de air_conditioner</title>
        <link rel="stylesheet" href="../css/estilos.css">
    </head>
    <body>
        <form action="../control/air_conditionerControl.php?a=<?php echo $acao ?>" method="post">
        <h1>Cadastro de air_conditioner</h1>
            <label for='id'>id</label>
<input type='text' value='<?php echo $obj?$obj['id']:''; ?>'name='id'><br>
<label for='brand'>brand</label>
<input type='text' value='<?php echo $obj?$obj['brand']:''; ?>'name='brand'><br>
<label for='btus'>btus</label>
<input type='text' value='<?php echo $obj?$obj['btus']:''; ?>'name='btus'><br>
<label for='description'>description</label>
<input type='text' value='<?php echo $obj?$obj['description']:''; ?>'name='description'><br>
<label for='location'>location</label>
<input type='text' value='<?php echo $obj?$obj['location']:''; ?>'name='location'><br>
<label for='id_pmoc'>id_pmoc</label>
<input type='text' value='<?php echo $obj?$obj['id_pmoc']:''; ?>'name='id_pmoc'><br>

             <button type="submit">Enviar</button>
        </form>
    </body>
</html>