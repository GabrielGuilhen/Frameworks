<?php
require_once("../model/conexao.php");
class PmocDao {
    private $con;
    public function __construct(){
       $this->con=(new Conexao())->conectar();
    }
function inserir($obj) {
    $sql = "INSERT INTO pmoc (id, name, creation_date, service_address, description, id_technician, id_client) VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = $this->con->prepare($sql);
    $id=$obj->getId();
$name=$obj->getName();
$creation_date=$obj->getCreation_date();
$service_address=$obj->getService_address();
$description=$obj->getDescription();
$id_technician=$obj->getId_technician();
$id_client=$obj->getId_client();

    $stmt->execute([$id,$name,$creation_date,$service_address,$description,$id_technician,$id_client]);
}
function listaGeral(){
    $sql = "select * from pmoc";
    $query = $this->con->query($sql);
    $dados = $query->fetchAll(PDO::FETCH_ASSOC);
    return $dados;
}
 function buscaPorId($id){
    $sql = "select * from pmoc where id=$id";
    $query = $this->con->query($sql);
    $dados = $query->fetch(PDO::FETCH_ASSOC);
    return $dados;
}   
    function alterar($obj){
    $sql = "UPDATE pmoc SET id= ?,name= ?,creation_date= ?,service_address= ?,description= ?,id_technician= ?,id_client= ? WHERE id=?";
    $stmt = $this->con->prepare($sql);
    $id=$obj->getId();
$name=$obj->getName();
$creation_date=$obj->getCreation_date();
$service_address=$obj->getService_address();
$description=$obj->getDescription();
$id_technician=$obj->getId_technician();
$id_client=$obj->getId_client();

    $stmt->execute([$id,$name,$creation_date,$service_address,$description,$id_technician,$id_client, $id]);
    header("Location:../view/listaPmoc.php");
}   
function excluir($id){
    $sql = "delete from pmoc where id=$id";
    $query = $this->con->query($sql);
    header("Location:../view/listaPmoc.php");
}
}
?>