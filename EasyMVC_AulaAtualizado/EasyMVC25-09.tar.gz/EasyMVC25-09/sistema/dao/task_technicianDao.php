<?php
require_once("../model/conexao.php");
class Task_technicianDao {
    private $con;
    public function __construct(){
       $this->con=(new Conexao())->conectar();
    }
function inserir($obj) {
    $sql = "INSERT INTO task_technician (id, id_task, id_technician, status, is_owner, invited_by, invited_at) VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = $this->con->prepare($sql);
    $id=$obj->getId();
$id_task=$obj->getId_task();
$id_technician=$obj->getId_technician();
$status=$obj->getStatus();
$is_owner=$obj->getIs_owner();
$invited_by=$obj->getInvited_by();
$invited_at=$obj->getInvited_at();

    $stmt->execute([$id,$id_task,$id_technician,$status,$is_owner,$invited_by,$invited_at]);
}
function listaGeral(){
    $sql = "select * from task_technician";
    $query = $this->con->query($sql);
    $dados = $query->fetchAll(PDO::FETCH_ASSOC);
    return $dados;
}
 function buscaPorId($id){
    $sql = "select * from task_technician where id=$id";
    $query = $this->con->query($sql);
    $dados = $query->fetch(PDO::FETCH_ASSOC);
    return $dados;
}   
    function alterar($obj){
    $sql = "UPDATE task_technician SET id= ?,id_task= ?,id_technician= ?,status= ?,is_owner= ?,invited_by= ?,invited_at= ? WHERE id=?";
    $stmt = $this->con->prepare($sql);
    $id=$obj->getId();
$id_task=$obj->getId_task();
$id_technician=$obj->getId_technician();
$status=$obj->getStatus();
$is_owner=$obj->getIs_owner();
$invited_by=$obj->getInvited_by();
$invited_at=$obj->getInvited_at();

    $stmt->execute([$id,$id_task,$id_technician,$status,$is_owner,$invited_by,$invited_at, $id]);
    header("Location:../view/listaTask_technician.php");
}   
function excluir($id){
    $sql = "delete from task_technician where id=$id";
    $query = $this->con->query($sql);
    header("Location:../view/listaTask_technician.php");
}
}
?>