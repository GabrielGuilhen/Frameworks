<?php
require_once("../model/conexao.php");
class BudgetDao {
    private $con;
    public function __construct(){
       $this->con=(new Conexao())->conectar();
    }
function inserir($obj) {
    $sql = "INSERT INTO budget (id, title, description, validity, value, status, id_technician, id_client) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $this->con->prepare($sql);
    $id=$obj->getId();
$title=$obj->getTitle();
$description=$obj->getDescription();
$validity=$obj->getValidity();
$value=$obj->getValue();
$status=$obj->getStatus();
$id_technician=$obj->getId_technician();
$id_client=$obj->getId_client();

    $stmt->execute([$id,$title,$description,$validity,$value,$status,$id_technician,$id_client]);
}
function listaGeral(){
    $sql = "select * from budget";
    $query = $this->con->query($sql);
    $dados = $query->fetchAll(PDO::FETCH_ASSOC);
    return $dados;
}
 function buscaPorId($id){
    $sql = "select * from budget where id=$id";
    $query = $this->con->query($sql);
    $dados = $query->fetch(PDO::FETCH_ASSOC);
    return $dados;
}   
    function alterar($obj){
    $sql = "UPDATE budget SET id= ?,title= ?,description= ?,validity= ?,value= ?,status= ?,id_technician= ?,id_client= ? WHERE id=?";
    $stmt = $this->con->prepare($sql);
    $id=$obj->getId();
$title=$obj->getTitle();
$description=$obj->getDescription();
$validity=$obj->getValidity();
$value=$obj->getValue();
$status=$obj->getStatus();
$id_technician=$obj->getId_technician();
$id_client=$obj->getId_client();

    $stmt->execute([$id,$title,$description,$validity,$value,$status,$id_technician,$id_client, $id]);
    header("Location:../view/listaBudget.php");
}   
function excluir($id){
    $sql = "delete from budget where id=$id";
    $query = $this->con->query($sql);
    header("Location:../view/listaBudget.php");
}
}
?>