<?php
require_once("../model/conexao.php");
class TechnicianDao {
    private $con;
    public function __construct(){
       $this->con=(new Conexao())->conectar();
    }
function inserir($obj) {
    $sql = "INSERT INTO technician (id, cpf_cnpj, name, address, phone, crea, email, password) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $this->con->prepare($sql);
    $id=$obj->getId();
$cpf_cnpj=$obj->getCpf_cnpj();
$name=$obj->getName();
$address=$obj->getAddress();
$phone=$obj->getPhone();
$crea=$obj->getCrea();
$email=$obj->getEmail();
$password=$obj->getPassword();

    $stmt->execute([$id,$cpf_cnpj,$name,$address,$phone,$crea,$email,$password]);
}
function listaGeral(){
    $sql = "select * from technician";
    $query = $this->con->query($sql);
    $dados = $query->fetchAll(PDO::FETCH_ASSOC);
    return $dados;
}
 function buscaPorId($id){
    $sql = "select * from technician where id=$id";
    $query = $this->con->query($sql);
    $dados = $query->fetch(PDO::FETCH_ASSOC);
    return $dados;
}   
    function alterar($obj){
    $sql = "UPDATE technician SET id= ?,cpf_cnpj= ?,name= ?,address= ?,phone= ?,crea= ?,email= ?,password= ? WHERE id=?";
    $stmt = $this->con->prepare($sql);
    $id=$obj->getId();
$cpf_cnpj=$obj->getCpf_cnpj();
$name=$obj->getName();
$address=$obj->getAddress();
$phone=$obj->getPhone();
$crea=$obj->getCrea();
$email=$obj->getEmail();
$password=$obj->getPassword();

    $stmt->execute([$id,$cpf_cnpj,$name,$address,$phone,$crea,$email,$password, $id]);
    header("Location:../view/listaTechnician.php");
}   
function excluir($id){
    $sql = "delete from technician where id=$id";
    $query = $this->con->query($sql);
    header("Location:../view/listaTechnician.php");
}
}
?>