<?php
require_once("../model/conexao.php");
class Air_conditionerDao {
    private $con;
    public function __construct(){
       $this->con=(new Conexao())->conectar();
    }
function inserir($obj) {
    $sql = "INSERT INTO air_conditioner (id, brand, btus, description, location, id_pmoc) VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $this->con->prepare($sql);
    $id=$obj->getId();
$brand=$obj->getBrand();
$btus=$obj->getBtus();
$description=$obj->getDescription();
$location=$obj->getLocation();
$id_pmoc=$obj->getId_pmoc();

    $stmt->execute([$id,$brand,$btus,$description,$location,$id_pmoc]);
}
function listaGeral(){
    $sql = "select * from air_conditioner";
    $query = $this->con->query($sql);
    $dados = $query->fetchAll(PDO::FETCH_ASSOC);
    return $dados;
}
 function buscaPorId($id){
    $sql = "select * from air_conditioner where id=$id";
    $query = $this->con->query($sql);
    $dados = $query->fetch(PDO::FETCH_ASSOC);
    return $dados;
}   
    function alterar($obj){
    $sql = "UPDATE air_conditioner SET id= ?,brand= ?,btus= ?,description= ?,location= ?,id_pmoc= ? WHERE id=?";
    $stmt = $this->con->prepare($sql);
    $id=$obj->getId();
$brand=$obj->getBrand();
$btus=$obj->getBtus();
$description=$obj->getDescription();
$location=$obj->getLocation();
$id_pmoc=$obj->getId_pmoc();

    $stmt->execute([$id,$brand,$btus,$description,$location,$id_pmoc, $id]);
    header("Location:../view/listaAir_conditioner.php");
}   
function excluir($id){
    $sql = "delete from air_conditioner where id=$id";
    $query = $this->con->query($sql);
    header("Location:../view/listaAir_conditioner.php");
}
}
?>