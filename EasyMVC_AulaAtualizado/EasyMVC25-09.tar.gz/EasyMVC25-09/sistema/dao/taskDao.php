<?php
require_once("../model/conexao.php");
class TaskDao {
    private $con;
    public function __construct(){
       $this->con=(new Conexao())->conectar();
    }
function inserir($obj) {
    $sql = "INSERT INTO task (id, title, description, scheduled_date, scheduled_time, location, task_status, id_client) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $this->con->prepare($sql);
    $id=$obj->getId();
$title=$obj->getTitle();
$description=$obj->getDescription();
$scheduled_date=$obj->getScheduled_date();
$scheduled_time=$obj->getScheduled_time();
$location=$obj->getLocation();
$task_status=$obj->getTask_status();
$id_client=$obj->getId_client();

    $stmt->execute([$id,$title,$description,$scheduled_date,$scheduled_time,$location,$task_status,$id_client]);
}
function listaGeral(){
    $sql = "select * from task";
    $query = $this->con->query($sql);
    $dados = $query->fetchAll(PDO::FETCH_ASSOC);
    return $dados;
}
 function buscaPorId($id){
    $sql = "select * from task where id=$id";
    $query = $this->con->query($sql);
    $dados = $query->fetch(PDO::FETCH_ASSOC);
    return $dados;
}   
    function alterar($obj){
    $sql = "UPDATE task SET id= ?,title= ?,description= ?,scheduled_date= ?,scheduled_time= ?,location= ?,task_status= ?,id_client= ? WHERE id=?";
    $stmt = $this->con->prepare($sql);
    $id=$obj->getId();
$title=$obj->getTitle();
$description=$obj->getDescription();
$scheduled_date=$obj->getScheduled_date();
$scheduled_time=$obj->getScheduled_time();
$location=$obj->getLocation();
$task_status=$obj->getTask_status();
$id_client=$obj->getId_client();

    $stmt->execute([$id,$title,$description,$scheduled_date,$scheduled_time,$location,$task_status,$id_client, $id]);
    header("Location:../view/listaTask.php");
}   
function excluir($id){
    $sql = "delete from task where id=$id";
    $query = $this->con->query($sql);
    header("Location:../view/listaTask.php");
}
}
?>