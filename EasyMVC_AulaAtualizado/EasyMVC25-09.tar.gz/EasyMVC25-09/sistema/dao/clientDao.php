<?php
require_once("../model/conexao.php");
class ClientDao {
    private $con;
    public function __construct(){
       $this->con=(new Conexao())->conectar();
    }
function inserir($obj) {
    $sql = "INSERT INTO client (id, name, phone, id_technician) VALUES (?, ?, ?, ?)";
    $stmt = $this->con->prepare($sql);
    $id=$obj->getId();
$name=$obj->getName();
$phone=$obj->getPhone();
$id_technician=$obj->getId_technician();

    $stmt->execute([$id,$name,$phone,$id_technician]);
}
function listaGeral(){
    $sql = "select * from client";
    $query = $this->con->query($sql);
    $dados = $query->fetchAll(PDO::FETCH_ASSOC);
    return $dados;
}
 function buscaPorId($id){
    $sql = "select * from client where id=$id";
    $query = $this->con->query($sql);
    $dados = $query->fetch(PDO::FETCH_ASSOC);
    return $dados;
}   
    function alterar($obj){
    $sql = "UPDATE client SET id= ?,name= ?,phone= ?,id_technician= ? WHERE id=?";
    $stmt = $this->con->prepare($sql);
    $id=$obj->getId();
$name=$obj->getName();
$phone=$obj->getPhone();
$id_technician=$obj->getId_technician();

    $stmt->execute([$id,$name,$phone,$id_technician, $id]);
    header("Location:../view/listaClient.php");
}   
function excluir($id){
    $sql = "delete from client where id=$id";
    $query = $this->con->query($sql);
    header("Location:../view/listaClient.php");
}
}
?>