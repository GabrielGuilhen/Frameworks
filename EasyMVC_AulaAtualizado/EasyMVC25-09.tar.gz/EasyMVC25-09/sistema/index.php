<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Climate_db</title>
    <style>
    body {
        margin: 0;
        font-family: Arial, sans-serif;
    }
    .cabecalho {
        width: 100%;
        height: 200px;
        background-color: #2c3e50;
        color: white;
        display: flex;
        justify-content: center;
        align-items: center;
        font-size: 24px;
        font-weight: bold;
    }
    .menu {
        width: 100%;
        height: 100px;
        background-color: #34495e;
        display: flex;
        align-items: center;
        padding-left: 20px;
    }
    .menu ul {
        list-style: none;
        margin: 0;
        padding: 0;
        display: flex;
        gap: 40px;
    }
    .menu li {
        position: relative;
    }
    .menu a {
        color: white;
        text-decoration: none;
        font-size: 18px;
        padding: 10px;
        display: block;
    }
    .menu li ul {
        display: none;
        position: absolute;
        top: 100%;
        left: 0;
        background-color: #2c3e50;
        list-style: none;
        padding: 0;
        margin: 0;
        min-width: 200px;
    }
    .menu li ul li a {
        padding: 10px;
        font-size: 16px;
    }
    .menu li:hover ul {
        display: block;
    }
    .conteudo {
        min-height: calc(100vh - 300px);
        padding: 20px;
        background-color: #ecf0f1;
    }
    </style>
</head>
<body>
    <div class="cabecalho">
        Sistema Climate_db
    </div>
    <div class="menu">
        <ul>
            <li>
                <a href="#">Cadastros</a>
                <ul>
                    <li><a href="view/air_conditioner.php">Cadastro de Air_conditioner</a></li>
                <li><a href="view/budget.php">Cadastro de Budget</a></li>
                <li><a href="view/client.php">Cadastro de Client</a></li>
                <li><a href="view/pmoc.php">Cadastro de Pmoc</a></li>
                <li><a href="view/task.php">Cadastro de Task</a></li>
                <li><a href="view/task_technician.php">Cadastro de Task_technician</a></li>
                <li><a href="view/technician.php">Cadastro de Technician</a></li>
                
                </ul>
            </li>
            <li>
                <a href="#">Relatórios</a>
                <ul>
                    <li><a href="view/listaAir_conditioner.php">Relatório de Air_conditioner</a></li>
                <li><a href="view/listaBudget.php">Relatório de Budget</a></li>
                <li><a href="view/listaClient.php">Relatório de Client</a></li>
                <li><a href="view/listaPmoc.php">Relatório de Pmoc</a></li>
                <li><a href="view/listaTask.php">Relatório de Task</a></li>
                <li><a href="view/listaTask_technician.php">Relatório de Task_technician</a></li>
                <li><a href="view/listaTechnician.php">Relatório de Technician</a></li>
                
                </ul>
            </li>
        </ul>
    </div>
    <div class="conteudo">
        <h2>Bem-vindo ao Sistema Climate_db!</h2>
        <p>Utilize o menu acima para navegar pelas funcionalidades do sistema.</p>
        <p>Você pode acessar os cadastros e relatórios através dos menus correspondentes.</p>
    </div>
</body>
</html>