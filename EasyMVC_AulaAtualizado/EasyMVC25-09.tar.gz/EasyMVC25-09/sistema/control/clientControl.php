<?php
require_once("../model/client.php");
require_once("../dao/clientDao.php");
class ClientControl {
    private $client;
    private $acao;
    private $dao;
    public function __construct(){
       $this->client=new Client();
      $this->dao=new ClientDao();
      $this->acao=$_GET["a"];
      $this->verificaAcao(); 
    }
    function verificaAcao(){
       switch($this->acao){
          case 1:
            $this->inserir();
          break;
          case 2:
            $this->excluir();
          break;
          case 3;
            $this->alterar();
          break;
       }
    }
  
    function inserir(){
        $this->client->setId($_POST['id']);
		$this->client->setName($_POST['name']);
		$this->client->setPhone($_POST['phone']);
		$this->client->setId_technician($_POST['id_technician']);
		
        $this->dao->inserir($this->client);
    }
    function excluir(){
        $this->dao->excluir($_REQUEST['id']);
    }
    function alterar(){
    $this->client->setId($_POST['id']);
		$this->client->setName($_POST['name']);
		$this->client->setPhone($_POST['phone']);
		$this->client->setId_technician($_POST['id_technician']);
		
    $this->dao->alterar($this->client);
}
    function buscarId(Client $client){}
    function buscaTodos(){}

}
new ClientControl();
?>