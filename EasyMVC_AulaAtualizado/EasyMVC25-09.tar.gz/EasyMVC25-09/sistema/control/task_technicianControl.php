<?php
require_once("../model/task_technician.php");
require_once("../dao/task_technicianDao.php");
class Task_technicianControl {
    private $task_technician;
    private $acao;
    private $dao;
    public function __construct(){
       $this->task_technician=new Task_technician();
      $this->dao=new Task_technicianDao();
      $this->acao=$_GET["a"];
      $this->verificaAcao(); 
    }
    function verificaAcao(){
       switch($this->acao){
          case 1:
            $this->inserir();
          break;
          case 2:
            $this->excluir();
          break;
          case 3;
            $this->alterar();
          break;
       }
    }
  
    function inserir(){
        $this->task_technician->setId($_POST['id']);
		$this->task_technician->setId_task($_POST['id_task']);
		$this->task_technician->setId_technician($_POST['id_technician']);
		$this->task_technician->setStatus($_POST['status']);
		$this->task_technician->setIs_owner($_POST['is_owner']);
		$this->task_technician->setInvited_by($_POST['invited_by']);
		$this->task_technician->setInvited_at($_POST['invited_at']);
		
        $this->dao->inserir($this->task_technician);
    }
    function excluir(){
        $this->dao->excluir($_REQUEST['id']);
    }
    function alterar(){
    $this->task_technician->setId($_POST['id']);
		$this->task_technician->setId_task($_POST['id_task']);
		$this->task_technician->setId_technician($_POST['id_technician']);
		$this->task_technician->setStatus($_POST['status']);
		$this->task_technician->setIs_owner($_POST['is_owner']);
		$this->task_technician->setInvited_by($_POST['invited_by']);
		$this->task_technician->setInvited_at($_POST['invited_at']);
		
    $this->dao->alterar($this->task_technician);
}
    function buscarId(Task_technician $task_technician){}
    function buscaTodos(){}

}
new Task_technicianControl();
?>