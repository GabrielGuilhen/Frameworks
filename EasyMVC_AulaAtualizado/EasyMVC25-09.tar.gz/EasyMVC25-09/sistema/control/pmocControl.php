<?php
require_once("../model/pmoc.php");
require_once("../dao/pmocDao.php");
class PmocControl {
    private $pmoc;
    private $acao;
    private $dao;
    public function __construct(){
       $this->pmoc=new Pmoc();
      $this->dao=new PmocDao();
      $this->acao=$_GET["a"];
      $this->verificaAcao(); 
    }
    function verificaAcao(){
       switch($this->acao){
          case 1:
            $this->inserir();
          break;
          case 2:
            $this->excluir();
          break;
          case 3;
            $this->alterar();
          break;
       }
    }
  
    function inserir(){
        $this->pmoc->setId($_POST['id']);
		$this->pmoc->setName($_POST['name']);
		$this->pmoc->setCreation_date($_POST['creation_date']);
		$this->pmoc->setService_address($_POST['service_address']);
		$this->pmoc->setDescription($_POST['description']);
		$this->pmoc->setId_technician($_POST['id_technician']);
		$this->pmoc->setId_client($_POST['id_client']);
		
        $this->dao->inserir($this->pmoc);
    }
    function excluir(){
        $this->dao->excluir($_REQUEST['id']);
    }
    function alterar(){
    $this->pmoc->setId($_POST['id']);
		$this->pmoc->setName($_POST['name']);
		$this->pmoc->setCreation_date($_POST['creation_date']);
		$this->pmoc->setService_address($_POST['service_address']);
		$this->pmoc->setDescription($_POST['description']);
		$this->pmoc->setId_technician($_POST['id_technician']);
		$this->pmoc->setId_client($_POST['id_client']);
		
    $this->dao->alterar($this->pmoc);
}
    function buscarId(Pmoc $pmoc){}
    function buscaTodos(){}

}
new PmocControl();
?>