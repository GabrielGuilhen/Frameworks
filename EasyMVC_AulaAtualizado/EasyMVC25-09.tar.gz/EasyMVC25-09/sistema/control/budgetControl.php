<?php
require_once("../model/budget.php");
require_once("../dao/budgetDao.php");
class BudgetControl {
    private $budget;
    private $acao;
    private $dao;
    public function __construct(){
       $this->budget=new Budget();
      $this->dao=new BudgetDao();
      $this->acao=$_GET["a"];
      $this->verificaAcao(); 
    }
    function verificaAcao(){
       switch($this->acao){
          case 1:
            $this->inserir();
          break;
          case 2:
            $this->excluir();
          break;
          case 3;
            $this->alterar();
          break;
       }
    }
  
    function inserir(){
        $this->budget->setId($_POST['id']);
		$this->budget->setTitle($_POST['title']);
		$this->budget->setDescription($_POST['description']);
		$this->budget->setValidity($_POST['validity']);
		$this->budget->setValue($_POST['value']);
		$this->budget->setStatus($_POST['status']);
		$this->budget->setId_technician($_POST['id_technician']);
		$this->budget->setId_client($_POST['id_client']);
		
        $this->dao->inserir($this->budget);
    }
    function excluir(){
        $this->dao->excluir($_REQUEST['id']);
    }
    function alterar(){
    $this->budget->setId($_POST['id']);
		$this->budget->setTitle($_POST['title']);
		$this->budget->setDescription($_POST['description']);
		$this->budget->setValidity($_POST['validity']);
		$this->budget->setValue($_POST['value']);
		$this->budget->setStatus($_POST['status']);
		$this->budget->setId_technician($_POST['id_technician']);
		$this->budget->setId_client($_POST['id_client']);
		
    $this->dao->alterar($this->budget);
}
    function buscarId(Budget $budget){}
    function buscaTodos(){}

}
new BudgetControl();
?>