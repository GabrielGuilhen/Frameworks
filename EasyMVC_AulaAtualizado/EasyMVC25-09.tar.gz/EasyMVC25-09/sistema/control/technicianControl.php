<?php
require_once("../model/technician.php");
require_once("../dao/technicianDao.php");
class TechnicianControl {
    private $technician;
    private $acao;
    private $dao;
    public function __construct(){
       $this->technician=new Technician();
      $this->dao=new TechnicianDao();
      $this->acao=$_GET["a"];
      $this->verificaAcao(); 
    }
    function verificaAcao(){
       switch($this->acao){
          case 1:
            $this->inserir();
          break;
          case 2:
            $this->excluir();
          break;
          case 3;
            $this->alterar();
          break;
       }
    }
  
    function inserir(){
        $this->technician->setId($_POST['id']);
		$this->technician->setCpf_cnpj($_POST['cpf_cnpj']);
		$this->technician->setName($_POST['name']);
		$this->technician->setAddress($_POST['address']);
		$this->technician->setPhone($_POST['phone']);
		$this->technician->setCrea($_POST['crea']);
		$this->technician->setEmail($_POST['email']);
		$this->technician->setPassword($_POST['password']);
		
        $this->dao->inserir($this->technician);
    }
    function excluir(){
        $this->dao->excluir($_REQUEST['id']);
    }
    function alterar(){
    $this->technician->setId($_POST['id']);
		$this->technician->setCpf_cnpj($_POST['cpf_cnpj']);
		$this->technician->setName($_POST['name']);
		$this->technician->setAddress($_POST['address']);
		$this->technician->setPhone($_POST['phone']);
		$this->technician->setCrea($_POST['crea']);
		$this->technician->setEmail($_POST['email']);
		$this->technician->setPassword($_POST['password']);
		
    $this->dao->alterar($this->technician);
}
    function buscarId(Technician $technician){}
    function buscaTodos(){}

}
new TechnicianControl();
?>