<?php
require_once("../model/task.php");
require_once("../dao/taskDao.php");
class TaskControl {
    private $task;
    private $acao;
    private $dao;
    public function __construct(){
       $this->task=new Task();
      $this->dao=new TaskDao();
      $this->acao=$_GET["a"];
      $this->verificaAcao(); 
    }
    function verificaAcao(){
       switch($this->acao){
          case 1:
            $this->inserir();
          break;
          case 2:
            $this->excluir();
          break;
          case 3;
            $this->alterar();
          break;
       }
    }
  
    function inserir(){
        $this->task->setId($_POST['id']);
		$this->task->setTitle($_POST['title']);
		$this->task->setDescription($_POST['description']);
		$this->task->setScheduled_date($_POST['scheduled_date']);
		$this->task->setScheduled_time($_POST['scheduled_time']);
		$this->task->setLocation($_POST['location']);
		$this->task->setTask_status($_POST['task_status']);
		$this->task->setId_client($_POST['id_client']);
		
        $this->dao->inserir($this->task);
    }
    function excluir(){
        $this->dao->excluir($_REQUEST['id']);
    }
    function alterar(){
    $this->task->setId($_POST['id']);
		$this->task->setTitle($_POST['title']);
		$this->task->setDescription($_POST['description']);
		$this->task->setScheduled_date($_POST['scheduled_date']);
		$this->task->setScheduled_time($_POST['scheduled_time']);
		$this->task->setLocation($_POST['location']);
		$this->task->setTask_status($_POST['task_status']);
		$this->task->setId_client($_POST['id_client']);
		
    $this->dao->alterar($this->task);
}
    function buscarId(Task $task){}
    function buscaTodos(){}

}
new TaskControl();
?>