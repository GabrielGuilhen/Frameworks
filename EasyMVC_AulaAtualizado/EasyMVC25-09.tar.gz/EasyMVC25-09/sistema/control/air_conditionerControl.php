<?php
require_once("../model/air_conditioner.php");
require_once("../dao/air_conditionerDao.php");
class Air_conditionerControl {
    private $air_conditioner;
    private $acao;
    private $dao;
    public function __construct(){
       $this->air_conditioner=new Air_conditioner();
      $this->dao=new Air_conditionerDao();
      $this->acao=$_GET["a"];
      $this->verificaAcao(); 
    }
    function verificaAcao(){
       switch($this->acao){
          case 1:
            $this->inserir();
          break;
          case 2:
            $this->excluir();
          break;
          case 3;
            $this->alterar();
          break;
       }
    }
  
    function inserir(){
        $this->air_conditioner->setId($_POST['id']);
		$this->air_conditioner->setBrand($_POST['brand']);
		$this->air_conditioner->setBtus($_POST['btus']);
		$this->air_conditioner->setDescription($_POST['description']);
		$this->air_conditioner->setLocation($_POST['location']);
		$this->air_conditioner->setId_pmoc($_POST['id_pmoc']);
		
        $this->dao->inserir($this->air_conditioner);
    }
    function excluir(){
        $this->dao->excluir($_REQUEST['id']);
    }
    function alterar(){
    $this->air_conditioner->setId($_POST['id']);
		$this->air_conditioner->setBrand($_POST['brand']);
		$this->air_conditioner->setBtus($_POST['btus']);
		$this->air_conditioner->setDescription($_POST['description']);
		$this->air_conditioner->setLocation($_POST['location']);
		$this->air_conditioner->setId_pmoc($_POST['id_pmoc']);
		
    $this->dao->alterar($this->air_conditioner);
}
    function buscarId(Air_conditioner $air_conditioner){}
    function buscaTodos(){}

}
new Air_conditionerControl();
?>