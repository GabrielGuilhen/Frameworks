<?php
class Cidade {
	private $id;
	private $nome;
	private $populacao;

	function getId(){
		return $this->id;
	}
	function setId($id){
		$this->id=$id;
	}
	function getNome(){
		return $this->nome;
	}
	function setNome($nome){
		$this->nome=$nome;
	}
	function getPopulacao(){
		return $this->populacao;
	}
	function setPopulacao($populacao){
		$this->populacao=$populacao;
	}

}
?>