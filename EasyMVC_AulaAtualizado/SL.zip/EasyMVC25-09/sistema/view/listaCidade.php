
<html>
    <head>
        <title>Lista de cidade</title>
        <link rel="stylesheet" href="../css/estilos.css">
    </head>
    <body>
      <?php
      require_once("../dao/cidadeDao.php");
   $dao=new cidadeDAO();
   $dados=$dao->listaGeral();
    echo "<table border=1>";
    foreach($dados as $dado){
        echo "<tr>";
       echo $dado['id'];echo $dado['nome'];echo $dado['populacao'];
       echo "<td>".
       "<a href='../control/cidadeControl.php?id=&a=2'> Excluir</a>".
       "</td>";
       echo "<td>" . 
        "<a href='../view/cidade.php?id='> Alterar</a>" .
       "</td>";
       echo "</tr>";
    }
    echo "</table>";
     ?>  
    </body>
</html>