<html>
    <head>
        <title>Cadastro de cidade</title>
        <link rel="stylesheet" href="../css/estilos.css">
    </head>
    <body>
        <form action="../control/cidadeControl.php?a=1" method="post">
        <h1>Cadastro de cidade</h1>
            <label for='id'>id</label>
<input type='text' name='id'><br>
<label for='nome'>nome</label>
<input type='text' name='nome'><br>
<label for='populacao'>populacao</label>
<input type='text' name='populacao'><br>

             <button type="submit">Enviar</button>
        </form>
    </body>
</html>