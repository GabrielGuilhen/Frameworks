
<html>
    <head>
        <title>Lista de estado</title>
        <link rel="stylesheet" href="../css/estilos.css">
    </head>
    <body>
      <?php
      require_once("../dao/estadoDao.php");
   $dao=new estadoDAO();
   $dados=$dao->listaGeral();
    echo "<table border=1>";
    foreach($dados as $dado){
        echo "<tr>";
       echo $dado['id'];echo $dado['nome'];echo $dado['sigla'];
       echo "<td>".
       "<a href='../control/estadoControl.php?id=&a=2'> Excluir</a>".
       "</td>";
       echo "<td>" . 
        "<a href='../view/estado.php?id='> Alterar</a>" .
       "</td>";
       echo "</tr>";
    }
    echo "</table>";
     ?>  
    </body>
</html>