<?php
require_once("../model/conexao.php");
class EstadoDao {
    private $con;
    public function __construct(){
       $this->con=(new Conexao())->conectar();
    }
function inserir($obj) {
    $sql = "INSERT INTO estado (id, nome, sigla) VALUES (?, ?, ?)";
    $stmt = $this->con->prepare($sql);
    $id=$obj->getId();
$nome=$obj->getNome();
$sigla=$obj->getSigla();

    $stmt->execute([$id,$nome,$sigla]);
}
function listaGeral(){
    $sql = "select * from estado";
    $query = $this->con->query($sql);
    $dados = $query->fetchAll(PDO::FETCH_ASSOC);
    return $dados;
}
 function buscaPorId($id){
    $sql = "select * from estado where id=$id";
    $query = $this->con->query($sql);
    $dados = $query->fetch(PDO::FETCH_ASSOC);
    return $dados;
}   
    function alterar($obj){
    $sql = "UPDATE estado SET id= ?,nome= ?,sigla= ? WHERE id=?";
    $stmt = $this->con->prepare($sql);
    $id=$obj->getId();
$nome=$obj->getNome();
$sigla=$obj->getSigla();

    $stmt->execute([$id,$nome,$sigla, $id]);
    header("Location:../view/listaEstado.php");
}   
function excluir($id){
    $sql = "delete from estado where id=$id";
    $query = $this->con->query($sql);
    header("Location:../view/listaEstado.php");
}
}
?>