<?php
require_once("../model/conexao.php");
class CidadeDao {
    private $con;
    public function __construct(){
       $this->con=(new Conexao())->conectar();
    }
function inserir($obj) {
    $sql = "INSERT INTO cidade (id, nome, populacao) VALUES (?, ?, ?)";
    $stmt = $this->con->prepare($sql);
    $id=$obj->getId();
$nome=$obj->getNome();
$populacao=$obj->getPopulacao();

    $stmt->execute([$id,$nome,$populacao]);
}
function listaGeral(){
    $sql = "select * from cidade";
    $query = $this->con->query($sql);
    $dados = $query->fetchAll(PDO::FETCH_ASSOC);
    return $dados;
}
 function buscaPorId($id){
    $sql = "select * from cidade where id=$id";
    $query = $this->con->query($sql);
    $dados = $query->fetch(PDO::FETCH_ASSOC);
    return $dados;
}   
    function alterar($obj){
    $sql = "UPDATE cidade SET id= ?,nome= ?,populacao= ? WHERE id=?";
    $stmt = $this->con->prepare($sql);
    $id=$obj->getId();
$nome=$obj->getNome();
$populacao=$obj->getPopulacao();

    $stmt->execute([$id,$nome,$populacao, $id]);
    header("Location:../view/listaCidade.php");
}   
function excluir($id){
    $sql = "delete from cidade where id=$id";
    $query = $this->con->query($sql);
    header("Location:../view/listaCidade.php");
}
}
?>