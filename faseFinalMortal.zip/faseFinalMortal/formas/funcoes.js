const canvas = document.getElementById('Canvas');
const ctx = canvas.getContext('2d');


//fazer circulo
ctx.beginPath();
//150 posição x
//100 posição y
//50 circuferencia
//0 = grau 0 onde vai começar
//math.pi * 2 é a circuferencia do circulo
ctx.arc(150, 100, 50, 0, Math.PI * 2, false);
ctx.fillStyle = 'blue'; // preenchimento azul
ctx.fill();//aplica o preenchimento azul no circulo. OBS:: PREENCHIMENTO É O INTERIOR DO CIRCULO 
ctx.strokeStyle = 'black'; // circuferencia preta
ctx.stroke();// aplicando a cor preta no circulo // SOMENTE A BORDA. BORDA=CIRCUFERENCIA
ctx.closePath();

ctx.beginPath();
/*
50 posição x
200 posição y
200 largura
100 altura
*/
ctx.rect(50,200,200,100);
ctx.fillStyle = 'green';// preenchimento interior
ctx.fill();
ctx.strokeStyle = 'black';//cor da borda
ctx.stroke();
ctx.closePath();

ctx.beginPath();
ctx.moveTo(300,300); // começa fazer a linha no ponto 300, 300 PRIMEIRO PONTO
ctx.lineTo(400,300); //se move para o ponto 400,300 SEGUNDO PONTO
ctx.lineTo(350,200); // se move para o ponto 350,200 TERCEIRO PONTO
ctx.closePath(); //fecha o triangulo
ctx.fillStyle = 'red'; // COR DE PREENCHIMENTO
ctx.fill();//APLICA A COR DO PREENCHIMENTO
ctx.strokeStyle = 'black'; //COR DE BORDA
ctx.stroke();//APLICA A COR DA BORDA
 /*POSSO USAR QUANTOS LINE TO EU QUISER, SERÁ A POSIÇÃO QUE EU QUERO QUE ELE VÁ*/ 