const canvas = document.getElementById('Canvas');
const ctx = canvas.getContext('2d');

//configurações do quadrado
let square = {
    x: 200,
    y: 200,
    size: 50,
    speed: 5, // velocidade de movimento
    color: 'black'
};

function drawSquare() {
    ctx.clearRect(0, 0, canvas.width, canvas.height); //limpa o canvas
    ctx.fillStyle = square.color;
    ctx.fillRect(square.x, square.y, square.size, square.size); //Desenha o quadrado
}

function moveSquare(event) {
    const key = event.key;

    if (key == "ArrowUp" && square.y > 0) {
        square.y -= square.speed; //move para cima
    } else if (key === "ArrowDown" && square.y + square.size < canvas.height) {
        square.y += square.speed; //move para baixo 
    } else if (key === "ArrowLeft" && square.x > 0) {
        square.x -= square.speed; //move para esquerda
    } else if (key === "ArrowRight" && square.x + square.size < canvas.width) {
        square.x += square.speed; //move para direita
    }

    drawSquare(); //atualiza o desenho
}
window.addEventListener('keydown', moveSquare);
drawSquare();