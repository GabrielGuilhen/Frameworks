const canvas = document.getElementById('Canvas');
const ctx = canvas.getContext('2d');

//configurações da bola
let bola = {
    x: canvas.width / 2,
    y: canvas.width / 2,
    radius: 20,
    dx: 2,//velocidade horizontal
    dy: 3, //velocidade vertical
    color: "blue",

};

//função para desenhar a bola
function desenhar() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    for (const arc of document.getElementsByTagName("arco")) {

        let x = arc.getAttribute("px")

        ctx.beginPath();
        ctx.arc(bola.x, bola.y, bola.radius, 0, Math.PI * 2); // desenha na posição x e y, o raio é 20etc...
        ctx.fillStyle = bola.color;
        ctx.fill();
        ctx.strokeStyle = 'black';
        ctx.stroke;
        ctx.closePath();

    }


}
//função para atualizar a posição da bola
function atualizaPosicaoBola() {
    //atualiza a posição da bola
    bola.x += bola.dx;
    bola.y += bola.dy;

    //Verifica colisão com as bordas horizontais
    if (bola.x + bola.radius > canvas.width || bola.x - bola.radius < 0) {
        bola.dx = -bola.dx;//Inverte a direção horizontal
    }
    //verifica colisão com as bordas verticais
    if (bola.y + bola.radius > canvas.height || bola.y - bola.radius < 0) {
        bola.dy = -bola.dy; //Inverte a direção vertical
    }

}

//função principal da animação
function animate() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);//Limpa o canvas não deixando "a linha" seguindo
    desenhar(); //desenha a bola
    atualizaPosicaoBola(); //Atualiza a posição da bola
    requestAnimationFrame(animate);//Requisita o proximo frame

}
//inicia a animação
animate();