  const  tela=document.getElementsByTagName("tela")[0];
  const  canvas=document.createElement("canvas");
  tela.appendChild(canvas);
  canvas.width= tela.getAttribute("largura")
  canvas.height= tela.getAttribute("altura")
  canvas.style="border:1px solid black";
  const ctx = canvas.getContext('2d');
  desenhar();
function desenhar() {
  ctx.clearRect(0,0,canvas.width,canvas.height);
  for(const arc of document.getElementsByTagName("arco")){
      let x = arc.getAttribute("px")||20;
      let y = arc.getAttribute("py")||20;
      let r = arc.getAttribute("raio")||20;
      let angIni = parseFloat(arc.getAttribute("angIni")||0);
      let angFim = parseFloat(arc.getAttribute("angFim")||Math.PI*2);
      let cor = arc.getAttribute("cor")||"green";

      ctx.beginPath();
      ctx.arc(x, y, r, angIni, angFim, false);
      ctx.fillStyle = cor;
      ctx.fill	();
      ctx.strokeStyle = 'black';
      ctx.stroke();
      ctx.closePath();
  }
}
function atualizar(){
  for (const arc of document.getElementsByTagName("arco")) {
      if(arc.getAttribute("animar")){
        let n=parseInt(arc.getAttribute("px"));
        n+=2;
        if(n>canvas.width)n=0;
        arc.setAttribute("px", n);
      }
  }
}
function animar(){
  desenhar();
  atualizar();
  requestAnimationFrame(animar)
}
animar();

