const canvas = document.getElementById('canvas');
const ctx = canvas.getContext('2d');
canvas.width = window.innerWidth;
canvas.heigth = window.innerHeight;


//configurações do circulo
let circle = {
    x: canvas.width / 2,
    y: canvas.width / 2,
    radius: 20,
    color: "blue",
    speed: 5,
    targetX: canvas.width / 2,
    targetY: canvas.heigth / 2
};

function drawCircle() {
    ctx.clearRect(0, 0, canvas.width)

}

function update() {
    const dx = circle.targetX - circle.x;
    const dy = circle.targetY - circle.y;
    const distance = Math.sqrt(dx * dx + dy * dy);

    if (distance > circle.speed) {
        circle.x += (dx / distance) * circle.speed;
        circle.y += (dy / distance) * circle.speed;
    } else {
        circle.x = circle.targetX;
        circle.y = circle.targetY;
    }

    drawCircle();
    requestAnimationFrame(update);

}

canvas.addEventListener('click', (event) => {
    const rect = canvas.getBoundingClientRect();
    circle.targetX = event.clientX - rect.left;
    circle.targetY = event.clientY - rect.top;

});

update();